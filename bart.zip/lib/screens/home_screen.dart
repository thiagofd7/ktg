import 'package:flutter/material.dart';

class HomeTela extends StatelessWidget {
  const HomeTela({super.key});


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home Page'),
        backgroundColor: const Color(0xFF520094),
      ),
      backgroundColor:
          const Color(0xFF520094), // Define a cor de fundo da Scaffold
    );
  }
}
